<?php 
namespace App\Models;
class inscripto extends \Illuminate\Database\Eloquent\Model{

    public $timestamps = false;
}