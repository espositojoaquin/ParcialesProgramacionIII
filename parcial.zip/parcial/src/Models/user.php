<?php 
namespace App\Models;
class User extends \Illuminate\Database\Eloquent\Model{

    public $timestamps = false;
}