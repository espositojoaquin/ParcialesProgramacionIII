<?php 
namespace App\Models;
class Materia extends \Illuminate\Database\Eloquent\Model{

    public $timestamps = false;
}