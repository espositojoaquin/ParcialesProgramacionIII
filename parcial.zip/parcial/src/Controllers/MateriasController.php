<?php
namespace App\Controllers;

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use App\Models\Materia;
use App\Utils\JsonWebToken;
use App\Utils\Funciones;
use App\Models\inscripto;



class MateriasController{
 
    public function add(Request $request, Response $response, $args)
    {   
       
        $rta ="";
       
        $materia = $request->getAttribute("materia");
        $rta = json_encode(array("ok" => $materia->save()));

        $response->getBody()->write($rta);

        return $response;
    }
    public function get(Request $request, Response $response, $args)
    {   
       
        $objeto = $request->getAttribute("materias");
        $rta = json_encode(array("ok" => $objeto)); 
        $response->getBody()->write($rta);

        return $response;
    }
    public function put(Request $request, Response $response, $args)
    {   
        $materia = new Materia();
        $mat = $request->getAttribute("materia");
        $prof = $request->getAttribute("profesor");
        Materia::where("id",$mat)->update(['profesor_id' => $prof]);
        $rta = json_encode(array("ok" =>"profesor asignado"));
        $response->getBody()->write($rta);

        return $response;
    }
    public function inscripcion(Request $request, Response $response, $args)
    {   
        $ins = new inscripto();
        $matid = $request->getAttribute("materia");
        $user = $request->getAttribute("usuario");
        $ins->alumno_id = $user->id;
        $ins->materia_id = $matid;
        $ins ->date = date("Y-m-d");
        $rta = json_encode(array("ok" =>$ins->save()));
        $response->getBody()->write($rta);

        return $response;
    }



    /*public function login(Request $request, Response $response, $args)
    {   
        
      
        $arrDatos = $request->getParsedBody();
        $objeto = materia::where('email',$arrDatos['email'])
        ->get();
        $retorno = json_encode(array("ok"=>JsonWebToken::obtenerJWT($objeto)));
        
        
         $response->getBody()->write($retorno);

        return $response;
    }*/

}