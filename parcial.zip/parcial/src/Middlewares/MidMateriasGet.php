<?php
namespace App\Middleware;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
//use Psr\Http\Message\ResponseInterface as Response;

use Slim\Psr7\Response;
use App\Utils\Funciones;
use App\Models\Materia;
use App\Models\User;
use App\Models\inscripto;


use stdClass;

class MateriasGetMiddleware
{
    /**
     * Example middleware invokable class
     *
     * @param  ServerRequest  $request PSR-7 request
     * @param  RequestHandler $handler PSR-15 request handler
     *
     * @return Response
     */
    public function __invoke(Request $request, RequestHandler $handler): Response
    {      
       $dato = Funciones::obtenerDatoGet($request->getUri()->getPath());
       
       if($dato=="materias")
       {   
           $retorno = [];
           $materias = Materia::join("users","users.id","=","materias.profesor_id")
           ->select('materias.id','materias.materia','materias.vacantes','materias.cuatrimestre','users.nombre','users.email')
           ->get();

           foreach($materias as $item)
           {     
                 $cantIns = count(inscripto::where("materia_id",$item->id)->get());
                 $obj = new stdClass();
                 $obj->materia = $item->materia;
                 $obj->vacantes = $item->vacantes;
                 $obj->cuatrimestre = $item->cuatrimestre;
                 $obj->nombre = $item->nombre;
                 $obj->email = $item->email;
                 $obj->inscriptos = $cantIns;
                 
                 if($item->vacantes == 0)
                 {
                     $obj->nombre = strtoupper($obj->nombre);
                     $obj->materia = strtoupper($obj->materia);
                     $obj->email = strtoupper($obj->email);
                 }

                 array_push($retorno,$obj);
           }
           $request= $request->withAttribute("materias",$retorno);
           $resp = new Response();
           $response = $handler->handle($request);
           $existingContent = (string) $response->getBody();
           $resp->getBody()->write($existingContent);   
           return $resp;
       }
       else
       {
           if(Funciones::validacionTipoToken("1","tipo_id"))
           {
              $materia = Materia::where("id",$dato)->get(); 
              $request= $request->withAttribute("materias",$materia);
              $resp = new Response();
              $response = $handler->handle($request);
              $existingContent = (string) $response->getBody();
              $resp->getBody()->write($existingContent);   
              return $resp;
    
           }
           else
           {   
                 if(Funciones::validacionTipoToken("2","tipo_id")||Funciones::validacionTipoToken("3","tipo_id"))
                 { 
                     $retornar = [];
                     $materia = Materia::where("id",$dato)->get();
                     $inscripciones = inscripto::join("users","inscriptos.alumno_id","=","users.id")
                     ->where("materia_id",$dato)
                     ->select('users.email','users.nombre','users.legajo')
                     ->get();  
                     if($materia!= "[]")
                     {   
                         $final = new stdClass();
                         $final->materia = $materia;
                            if($inscripciones!="[]")
                            {
                             $final->inscriptos= $inscripciones; 
                             
                            }
                            else
                            {
                             $final->inscriptos= "No hay inscriptos en esta materia"; 
                               
                            }
                            $request=  $request->withAttribute("materias",$final);
                            $resp = new Response();
                            $response = $handler->handle($request);
                            $existingContent = (string) $response->getBody();
                            $resp->getBody()->write($existingContent);   
                            return $resp;
                            
    
                     }
                     else
                     {
                        $resp = new Response();
                        $resp->getBody()->write(json_encode(array("Error" =>"No Existe la materia")));
                        return $resp;
                     }
                   
                 }
              
           }

       }
    
        
    }
}
