<?php
namespace App\Middleware;

use Psr\Http\Message\ServerRequestInterface as Request;
use Psr\Http\Server\RequestHandlerInterface as RequestHandler;
//use Psr\Http\Message\ResponseInterface as Response;

use Slim\Psr7\Response;
use App\Utils\Funciones;
use App\Models\Materia;
use App\Models\inscripto;
use App\Models\User;
use App\Utils\JsonWebToken;
use stdClass;

class MateriasPutMiddleware
{
    /**
     * Example middleware invokable class
     *
     * @param  ServerRequest  $request PSR-7 request
     * @param  RequestHandler $handler PSR-15 request handler
     *
     * @return Response
     */
    public function __invoke(Request $request, RequestHandler $handler): Response
    {      
       if(Funciones::validacionTipoToken("3","tipo_id"))
       { 
         $idMat = Funciones::obtenerDatoDelete($request->getUri()->getPath());
         $idProf = Funciones::obtenerDatoGet($request->getUri()->getPath());
          
         $mat = Materia::where("id",$idMat)->get();
         $prof = User::where("id",$idProf)
         ->where("tipo_id",2)->get();
          if($mat != "[]" && $prof != "[]")
          {
              
   
             $request= $request->withAttribute("materia",$idMat); 
             $request= $request->withAttribute("profesor",$idProf); 
             $resp = new Response();
             $response = $handler->handle($request);
             $existingContent = (string) $response->getBody();
             $resp->getBody()->write($existingContent);   
             return $resp;

          }
          else
          {
            $resp = new Response();
            $resp->getBody()->write(json_encode(array("Error" =>"Materia o profesor inexistente")));
            return $resp;
          }

       }
       else
       {   

           if(Funciones::validacionTipoToken("1","tipo_id"))
           { 
              $idMat = Funciones::obtenerDatoGet($request->getUri()->getPath());
              $verif = Funciones::obtenerDatoDelete($request->getUri()->getPath());
   
             // $mat = Materia::where("id",$idMat)->get();
             if(!is_numeric($verif))
             {
               $mat = Materia::find($idMat);
               if($mat!="[]")
               {  
                  if($mat->vacantes>0)
                  {
                     $mat->vacantes -= 1;
                     $mat->save();
                     $alumno = Funciones::retornoObjetoToken();
                     $request= $request->withAttribute("usuario",$alumno); 
                     $request= $request->withAttribute("materia",$idMat); 
                     $resp = new Response();
                     $response = $handler->handle($request);
                     $existingContent = (string) $response->getBody();
                     $resp->getBody()->write($existingContent);   
                     return $resp;
  
                  }
                  else
                  {
                    $resp = new Response();
                    $resp->getBody()->write(json_encode(array("Error" =>"No hay mas vacantes disponibles")));
                    return $resp;
                  }
  
               }
               else
               { 
                 $resp = new Response();
                 $resp->getBody()->write(json_encode(array("Error" =>"No Existe la materia")));
                 return $resp;
                
               }

             }
             else
             {
               $resp = new Response();
               $resp->getBody()->write(json_encode(array("Error" =>"solo administradores pueden asignar un profesor a una materia")));
               return $resp;
             }

           } 
           else
           {
             $resp = new Response();
             $resp->getBody()->write(json_encode(array("Error" =>"No se permiten profesores")));
             return $resp;
           }
               
          
       }
    
        
    }
}